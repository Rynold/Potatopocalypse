﻿using UnityEngine;
using System.Collections;

public class HouseScript : MonoBehaviour {

    public GameObject fire;
    bool hasCreatedFire;
    float xDisplacement;
	void Start () {
        if (GameObject.Find("Dino Head").transform.position.x < transform.position.x)
        {
            xDisplacement = 1;
        }
        else
            xDisplacement = -1;
	}
	
	// Update is called once per frame
	void Update () {
        if (this.GetComponent<Animator>().GetBool("Destroyed") && !hasCreatedFire)
        {
            hasCreatedFire = true;
            Instantiate(fire,new Vector3(transform.position.x + xDisplacement,transform.position.y,transform.position.z + 0.5f),Quaternion.Euler(0,0,0));
        }
	}
}
