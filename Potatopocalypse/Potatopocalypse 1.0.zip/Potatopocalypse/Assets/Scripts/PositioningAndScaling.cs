﻿using UnityEngine;
using System.Collections;

public class PositioningAndScaling : MonoBehaviour {

    GameObject house1;
    GameObject house2;
    GameObject dinoBody;
    GameObject dinoHead;
    GameObject volcano;
    GameObject smokeParticles;
    //GameObject potatoParticles;
    GameObject potatoGenerator;
    GameObject ground;
    GameObject score;
    GameObject multipler;


	void Start () {
        //Finding the object
        house1 = GameObject.Find("House1");
        house2 = GameObject.Find("House2");
        dinoBody = GameObject.Find("Dino Body");
        dinoHead = GameObject.Find("Dino Head");
        volcano = GameObject.Find("Background Volcano");
        smokeParticles = GameObject.Find("Smoke Particles");
        //potatoParticles = GameObject.Find("Potato Particles");
        potatoGenerator = GameObject.Find("Game Control");
        ground = GameObject.Find("Ground");
        score = GameObject.Find("Score Control");
        multipler = GameObject.Find("Multiplyer");

        //Setting the Objects position based on screen size
        gameObject.guiTexture.pixelInset = new Rect(0, 0, Screen.width, Screen.height);
        house1.transform.position = Camera.main.ScreenToWorldPoint(new Vector3(Screen.width/4,Screen.height - Screen.height,7));
        house2.transform.position = Camera.main.ScreenToWorldPoint(new Vector3((Screen.width / 4) + ((Screen.width / 4) * 2), Screen.height - Screen.height, 7));
        dinoBody.transform.position = Camera.main.ScreenToWorldPoint(new Vector3((Screen.width / 2), Screen.height - Screen.height, 7));
        dinoHead.transform.position = dinoBody.transform.position;
        volcano.transform.position = Camera.main.ScreenToWorldPoint(new Vector3(Screen.width / 2, Screen.height - Screen.height,8));
        smokeParticles.transform.position = Camera.main.ScreenToWorldPoint(new Vector3(Screen.width / 2, Screen.height /2 - 20, 9));
        //potatoParticles.transform.position = Camera.main.ScreenToWorldPoint(new Vector3(Screen.width / 2, Screen.height / 2 - 20, 8));
        potatoGenerator.transform.position = Camera.main.ScreenToWorldPoint(new Vector3(Screen.width / 2, Screen.height / 2, 7));
        ground.transform.position = Camera.main.ScreenToWorldPoint(new Vector3(Screen.width / 2, Screen.height - Screen.height, 7));
        score.transform.position = new Vector3(0, 0, -4);
        score.guiText.pixelOffset = new Vector2(Screen.width / 2, Screen.height - 25);
        multipler.transform.position = Camera.main.ScreenToWorldPoint(new Vector3(Screen.width / 2, Screen.height - 60,6));
        multipler.transform.localScale = new Vector3(2, 2, 0);
	}
}
