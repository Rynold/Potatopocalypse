﻿using UnityEngine;
using System.Collections;

public class HighscoreScript : MonoBehaviour {

	// Use this for initialization
	void Start () {
        transform.position = new Vector3(0, 0, -4);
        guiText.pixelOffset = new Vector2(Screen.width / 2, Screen.height - 25);
        guiText.text = ""+PlayerPrefs.GetFloat("HighScore");
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
