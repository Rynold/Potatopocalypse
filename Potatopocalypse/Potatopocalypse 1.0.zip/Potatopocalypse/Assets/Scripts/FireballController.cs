﻿using UnityEngine;
using System.Collections;

public class FireballController : MonoBehaviour {


    Vector3 velocity;
    Ray targetRay;
    RaycastHit hitInfo;
    Vector3 targetPosition;
    GameObject gameControl;
    float screenLeft;
    float screenRight;

    public void Initialize(Transform parent, Vector3 target)
    {
        transform.position = parent.position;
        transform.rotation = parent.rotation;
        targetRay = new Ray(transform.position, target);
        targetPosition = targetRay.GetPoint(12.0f);
        gameObject.SetActive(true);
    }
    void Start()
    {
        gameControl = GameObject.Find("Game Control");
        screenLeft = Camera.main.ScreenToWorldPoint(new Vector3(0, 0, 7)).x;
        screenRight = Camera.main.ScreenToWorldPoint(new Vector3(Screen.width, 0, 7)).x;
    }
	
	void Update () {    
        transform.position = Vector3.MoveTowards(transform.position, targetPosition, Time.deltaTime * 2.5f);
        if (transform.position == targetPosition || transform.position.x < screenLeft || transform.position.x > screenRight)
        {
            Deactivate();
        }
	}

    public void Deactivate()
    {
        gameControl.GetComponent<UniversalVariables>().multiplyer = 1;
        transform.position = GameObject.Find("Dino Head").GetComponent<DinoController>().stackPosition;
        gameObject.SetActive(false);
    }
}
