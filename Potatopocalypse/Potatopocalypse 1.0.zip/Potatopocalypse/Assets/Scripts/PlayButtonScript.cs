﻿using UnityEngine;
using System.Collections;

public class PlayButtonScript : MonoBehaviour {

	void Start () {
	
	}
    void OnMouseDown()
    {
        Application.LoadLevel("Main Game");
    }
	void Update () {
	
	}
}
