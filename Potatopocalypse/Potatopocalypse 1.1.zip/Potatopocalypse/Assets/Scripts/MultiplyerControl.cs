﻿using UnityEngine;
using System.Collections;

public class MultiplyerControl : MonoBehaviour {

    GameObject gameControl;
	void Start () {
        gameControl = GameObject.Find("Game Control");	
	}
	
	
	void Update () {
        GetComponent<Animator>().SetFloat("multiplyer", gameControl.GetComponent<UniversalVariables>().multiplyer);
	}
}
