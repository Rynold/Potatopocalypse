﻿using UnityEngine;
using System.Collections;

public class PauseWindowScript : MonoBehaviour {

    Rect pauseWindow;
    float width;
    float height;
    float buttonWidth;
    float buttonHeight;
	void Start () {
        this.gameObject.SetActive(false);
        width = Screen.width / 2;
        height = Screen.height / 2;
        buttonWidth = width / 2;
        buttonHeight = height / 4;
        pauseWindow = new Rect(Screen.width / 2 - (width / 2), Screen.height / 2 - (height / 2), width, height);
	}

    void OnGUI()
    {
        pauseWindow = GUI.Window(0, pauseWindow, WindowFunction, "Game Paused");
    }

    void WindowFunction(int windowID)
    {
        if (GUI.Button(new Rect(pauseWindow.width / 2 - (buttonWidth/2), pauseWindow.height/4, buttonWidth, buttonHeight), "Main Menu"))
        {
            GameObject.Find("Pause Button").GetComponent<PauseButtonScript>().paused = false;
            Time.timeScale = 1;
            Application.LoadLevel("Main Menu");
        }
    }
}
