﻿using UnityEngine;
using System.Collections;

public class ScoreController : MonoBehaviour {

    float highScore;
	void Start () {
        if (PlayerPrefs.GetFloat("HighScore") > 0.0f)
        {
            highScore = PlayerPrefs.GetFloat("HighScore");
        }
        else
            PlayerPrefs.SetFloat("HighScore", 0.0f);
	}
	
	// Update is called once per frame
	void Update () {
        GetComponent<GUIText>().text = ""+GameObject.Find("Game Control").GetComponent<UniversalVariables>().score;
        if (GameObject.Find("Game Control").GetComponent<UniversalVariables>().score > highScore)
        {
            PlayerPrefs.SetFloat("HighScore", GameObject.Find("Game Control").GetComponent<UniversalVariables>().score);
        }
        Debug.Log(PlayerPrefs.GetFloat("HighScore"));
	}
}
