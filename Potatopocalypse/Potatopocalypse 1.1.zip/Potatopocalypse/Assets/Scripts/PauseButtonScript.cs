﻿using UnityEngine;
using System.Collections;

public class PauseButtonScript : MonoBehaviour {

    public bool paused;
    public Texture off;
    public Texture on;
    public GameObject pauseWindow;
	void Start ()
    {
        paused = false;
	}
    void OnMouseDown()
    {
        if (!paused)
        {
            Time.timeScale = 0;
            paused = true;
            guiTexture.texture = off;
            pauseWindow.SetActive(true);
        }
        else
        {
            Time.timeScale = 1;
            paused = false;
            guiTexture.texture = on;
            pauseWindow.SetActive(false);
        }
    }
}
