﻿using UnityEngine;
using System.Collections;

public class UniversalVariables : MonoBehaviour {

    public float score;
    public float lives;
    public float multiplyer;
    float currentTime;
    float previousTime;
    GameObject houseLeft;
    GameObject houseRight;
    GameObject dino;
    public GameObject restartButton;
    public GameObject menuButton;
    bool hasCreatedTheButtons;
    public bool mashedBanger;
    public bool crippleChip;
    public bool hashseeker;
    public float powerUpTimer;

	void Start () {
        mashedBanger = false;
        crippleChip = false;
        hashseeker = false;
        hasCreatedTheButtons = false;
        multiplyer = 1;
        lives = 3;
        score = 0;
        currentTime = Mathf.Floor(Time.timeSinceLevelLoad);
        previousTime = currentTime;
        houseLeft = GameObject.Find("House1");
        houseRight = GameObject.Find("House2");
        dino = GameObject.Find("Dino Head");
        Debug.Log(Time.timeScale);
	}

    void Update()
    {
        currentTime = Mathf.Floor(Time.timeSinceLevelLoad);
        if(dino.GetComponent<Animator>().GetBool("isAlive"))
        {
            if (currentTime > previousTime)
            {
                powerUpTimer--;
                previousTime = currentTime;
                score += 1;
            }
        }
        if (multiplyer > 5)
            multiplyer = 5;


        if (lives == 2)
            houseLeft.GetComponent<Animator>().SetBool("Destroyed", true);
        else if (lives == 1)
            houseRight.GetComponent<Animator>().SetBool("Destroyed", true);
        else if (lives == 0)
        {
            dino.GetComponent<Animator>().SetBool("isAlive", false);
            if (!hasCreatedTheButtons)
            {
                Instantiate(restartButton, new Vector3(0, 0, 0), Quaternion.Euler(0, 0, 0));
                Instantiate(menuButton, new Vector3(0, 0, 0), Quaternion.Euler(0, 0, 0));
                hasCreatedTheButtons = true;
            }
        }


        if (powerUpTimer <= 0)
        {
            mashedBanger = false;
            hashseeker = false;
            crippleChip = false;
            powerUpTimer = 0;
        }
    }
}
